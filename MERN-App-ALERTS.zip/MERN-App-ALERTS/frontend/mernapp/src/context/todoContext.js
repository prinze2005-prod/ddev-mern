import { createContext } from "react";

const todoContext = createContext();

export default todoContext;