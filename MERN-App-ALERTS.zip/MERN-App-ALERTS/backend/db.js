const mongoose = require("mongoose");
const mongoURI = process.env.db;

const connectToMongo = () => {
  mongoose.connect(mongoURI, () => {
    console.log("Database Connected Boss");
  });
};

module.exports = connectToMongo;

