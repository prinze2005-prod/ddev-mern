open forntend folder in terminal and do: npm install
open backend folder in terminal and do: npm install

Open mernapp in terminal and npm start

