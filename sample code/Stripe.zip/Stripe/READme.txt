for server startup:
1. "cd server/"
2. "npm init -y"
3. "npm i express stripe dotenv" this will load enviroment variables.
4. "npm i --save-dev nodemon"
5. "npm i express-list-endpoints" 


to start server after
1. "npm run devStart"
